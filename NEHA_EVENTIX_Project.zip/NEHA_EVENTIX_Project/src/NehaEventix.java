import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.*;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class NehaEventix extends JFrame {
    private final String[] events = {"Midnight Frequency — Music Festival — ₹799", "Mumbai Food Carnival — Food — ₹499", "TechNext 2026 — Technology — ₹999", "Canvas & Coffee — Art — ₹399", "Laugh Out Loud — Comedy — ₹599"};
    private final JComboBox<String> eventBox = new JComboBox<>(events);
    private final DefaultListModel<String> seatModel = new DefaultListModel<>();
    private final JList<String> seatList = new JList<>(seatModel);
    private final JTextField nameField = new JTextField(18);
    private final JTextField emailField = new JTextField(18);
    private final JTextArea output = new JTextArea(8, 42);
    private final Set<String> booked = new HashSet<>();
    private final Path dataFile = Paths.get(System.getProperty("user.home"), "neha-eventix-bookings.csv");
    private final JLabel status = new JLabel("Demo mode: bookings are saved on this computer.");

    public NehaEventix() {
        super("NEHA EVENTIX | Events • Tickets • Experiences");
        setDefaultCloseOperation(EXIT_ON_CLOSE); setSize(900, 650); setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(13, 18, 34));
        JPanel root = new JPanel(new BorderLayout(16,16)); root.setBackground(new Color(13,18,34)); root.setBorder(new EmptyBorder(22,22,22,22)); setContentPane(root);
        JLabel brand = new JLabel("NEHA EVENTIX"); brand.setFont(new Font("SansSerif", Font.BOLD, 30)); brand.setForeground(new Color(255, 190, 92));
        JLabel tagline = new JLabel("Events  •  Tickets  •  Experiences"); tagline.setForeground(new Color(210,216,232));
        JPanel header = new JPanel(new GridLayout(2,1,0,4)); header.setOpaque(false); header.add(brand); header.add(tagline); root.add(header, BorderLayout.NORTH);
        JPanel main = new JPanel(new GridLayout(1,2,16,0)); main.setOpaque(false); root.add(main, BorderLayout.CENTER);
        JPanel left = panel("Find your next experience"); left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.add(label("Select event")); eventBox.setMaximumSize(new Dimension(500,38)); left.add(eventBox); left.add(Box.createVerticalStrut(16));
        left.add(label("Your name")); left.add(nameField); left.add(Box.createVerticalStrut(10)); left.add(label("Email address")); left.add(emailField); left.add(Box.createVerticalStrut(16));
        JButton refresh = new JButton("Refresh available seats"); refresh.addActionListener(e -> refreshSeats()); left.add(refresh); left.add(Box.createVerticalStrut(12));
        left.add(label("Choose seat(s) — Ctrl/Command to select multiple")); seatList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION); seatList.setVisibleRowCount(10); left.add(new JScrollPane(seatList));
        JButton book = new JButton("Book selected seat(s)"); book.setBackground(new Color(255,190,92)); book.setForeground(new Color(25,28,42)); book.setFont(new Font("SansSerif",Font.BOLD,14)); book.addActionListener(e -> bookSeats()); left.add(Box.createVerticalStrut(12)); left.add(book);
        main.add(left);
        JPanel right = panel("Booking activity"); right.setLayout(new BorderLayout(8,8)); output.setEditable(false); output.setLineWrap(true); output.setWrapStyleWord(true); output.setBackground(new Color(10,14,27)); output.setForeground(new Color(230,235,247)); output.setBorder(new EmptyBorder(12,12,12,12)); right.add(new JScrollPane(output), BorderLayout.CENTER);
        JButton history = new JButton("View booking history"); history.addActionListener(e -> showHistory()); JButton export = new JButton("Export / open CSV location"); export.addActionListener(e -> JOptionPane.showMessageDialog(this,"Booking CSV is saved at:\n"+dataFile.toAbsolutePath(),"Booking file",JOptionPane.INFORMATION_MESSAGE));
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT)); actions.setOpaque(false); actions.add(history); actions.add(export); right.add(actions,BorderLayout.SOUTH); main.add(right);
        status.setForeground(new Color(255,205,130)); root.add(status,BorderLayout.SOUTH); eventBox.addActionListener(e -> refreshSeats()); refreshSeats(); output.setText("Welcome to NEHA EVENTIX!\n\nSelect an event, enter your details, choose available seats and book.\nThis packaged version saves bookings locally. Online database is not configured in this demo build.\n");
    }
    private JPanel panel(String title) { JPanel p = new JPanel(); p.setBackground(new Color(24,31,52)); p.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(55,67,98)), new EmptyBorder(16,16,16,16))); p.setForeground(Color.WHITE); p.setBorder(BorderFactory.createCompoundBorder(p.getBorder(), new EmptyBorder(0,0,0,0))); JLabel l = new JLabel(title); l.setForeground(new Color(255,190,92)); l.setFont(new Font("SansSerif",Font.BOLD,18)); p.add(l); return p; }
    private JLabel label(String s) { JLabel l = new JLabel(s); l.setForeground(new Color(220,226,241)); l.setBorder(new EmptyBorder(8,0,5,0)); return l; }
    private void refreshSeats() { seatModel.clear(); String event = String.valueOf(eventBox.getSelectedItem()); for(int i=1;i<=24;i++){ String seat=""+(char)('A'+(i-1)/8)+(i-1)%8+1; String key=event+"|"+seat; if(!booked.contains(key)) seatModel.addElement(seat+"   •   Available"); } }
    private int price() { String s=String.valueOf(eventBox.getSelectedItem()); java.util.regex.Matcher m=java.util.regex.Pattern.compile("₹(\\d+)").matcher(s); return m.find()?Integer.parseInt(m.group(1)):0; }
    private void bookSeats() {
        String name=nameField.getText().trim(), email=emailField.getText().trim(); java.util.List<String> selected=seatList.getSelectedValuesList();
        if(name.isEmpty()||email.isEmpty()||!email.contains("@")){JOptionPane.showMessageDialog(this,"Enter your name and a valid email address.","Check details",JOptionPane.WARNING_MESSAGE);return;}
        if(selected.isEmpty()){JOptionPane.showMessageDialog(this,"Please select at least one seat.","Select seat",JOptionPane.WARNING_MESSAGE);return;}
        String event=String.valueOf(eventBox.getSelectedItem()); int total=price()*selected.size(); String time=LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
        try { if(!Files.exists(dataFile)) Files.writeString(dataFile,"timestamp,name,email,event,seats,total\n"); String seats=String.join(" ",selected.stream().map(s->s.split("   ")[0]).toList()); String row=csv(time)+","+csv(name)+","+csv(email)+","+csv(event)+","+csv(seats)+","+total+"\n"; Files.writeString(dataFile,row,StandardOpenOption.APPEND); for(String s:selected) booked.add(event+"|"+s.split("   ")[0]); output.append("\nBOOKING CONFIRMED\nName: "+name+"\nEvent: "+event+"\nSeats: "+seats+"\nTickets: "+selected.size()+"\nTotal: ₹"+total+"\nReference: NE"+System.currentTimeMillis()%1000000+"\nSaved: "+time+"\n"); refreshSeats(); }
        catch(IOException ex){JOptionPane.showMessageDialog(this,"Could not save booking: "+ex.getMessage(),"File error",JOptionPane.ERROR_MESSAGE);}
    }
    private String csv(String s){return "\""+s.replace("\"","\"\"")+"\"";}
    private void showHistory(){try{if(!Files.exists(dataFile)){JOptionPane.showMessageDialog(this,"No bookings yet.");return;} JTextArea a=new JTextArea(Files.readString(dataFile),20,60);a.setEditable(false);JOptionPane.showMessageDialog(this,new JScrollPane(a),"Booking history",JOptionPane.INFORMATION_MESSAGE);}catch(IOException ex){JOptionPane.showMessageDialog(this,ex.getMessage());}}
    public static void main(String[] args){SwingUtilities.invokeLater(()->new NehaEventix().setVisible(true));}
}
