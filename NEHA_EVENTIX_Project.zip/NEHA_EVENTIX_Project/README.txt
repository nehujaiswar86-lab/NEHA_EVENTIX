NEHA EVENTIX — Student project package

CONTENTS
- NEHA_EVENTIX.jar: runnable Java Swing demo application.
- src/NehaEventix.java: Java source code.
- site/index.html: responsive event ticketing website demo.

RUN THE JAR
1. Install Java 17 or newer on the computer.
2. Double-click NEHA_EVENTIX.jar, or run: java -jar NEHA_EVENTIX.jar
3. The desktop app stores bookings locally in ~/neha-eventix-bookings.csv.

RUN THE WEBSITE
Open site/index.html in a browser. To publish it, upload index.html to Netlify Drop or deploy the site folder.

IMPORTANT LIMITATION
This package is a functional demonstration with local persistence. It does NOT yet connect to an online database, process payments, or provide a deployed backend/API. The browser demo uses localStorage and the desktop app uses a CSV file on the user's computer; these are not shared between devices. To meet the instructor's online database requirement, configure and deploy a backend/API and hosted database, then connect both clients to it. Do not put database passwords in frontend code.
