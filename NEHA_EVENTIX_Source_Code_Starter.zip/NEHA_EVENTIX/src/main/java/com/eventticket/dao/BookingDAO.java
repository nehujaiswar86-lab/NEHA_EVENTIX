package com.eventticket.dao;

import com.eventticket.model.Booking;
import com.eventticket.util.DBConnection;
import java.sql.*;
import java.util.*;

public class BookingDAO {
    public String book(int userId,int eventId,int seatId,double amount) throws SQLException {
        String code="EVT-"+UUID.randomUUID().toString().substring(0,8).toUpperCase();
        try(Connection c=DBConnection.getConnection()){
            c.setAutoCommit(false);
            try{
                String lock="SELECT status FROM seats WHERE id=? AND event_id=? FOR UPDATE";
                try(PreparedStatement p=c.prepareStatement(lock)){
                    p.setInt(1,seatId);p.setInt(2,eventId);
                    try(ResultSet r=p.executeQuery()){
                        if(!r.next() || !"AVAILABLE".equals(r.getString(1))){c.rollback();return null;}
                    }
                }
                try(PreparedStatement p=c.prepareStatement("UPDATE seats SET status='BOOKED' WHERE id=? AND status='AVAILABLE'")){
                    p.setInt(1,seatId); if(p.executeUpdate()!=1){c.rollback();return null;}
                }
                try(PreparedStatement p=c.prepareStatement(
                    "INSERT INTO bookings(user_id,event_id,seat_id,booking_code,amount) VALUES(?,?,?,?,?)")){
                    p.setInt(1,userId);p.setInt(2,eventId);p.setInt(3,seatId);p.setString(4,code);p.setDouble(5,amount);p.executeUpdate();
                }
                c.commit(); return code;
            }catch(SQLException e){c.rollback();throw e;}finally{c.setAutoCommit(true);}
        }
    }

    public List<Booking> getUserBookings(int userId) throws SQLException {
        List<Booking> list=new ArrayList<>();
        String sql="SELECT b.*,e.title,s.seat_number FROM bookings b JOIN events e ON e.id=b.event_id JOIN seats s ON s.id=b.seat_id WHERE b.user_id=? ORDER BY b.booking_date DESC";
        try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement(sql)){
            p.setInt(1,userId);try(ResultSet r=p.executeQuery()){
                while(r.next())list.add(map(r));
            }
        } return list;
    }

    public void cancel(int bookingId,int userId) throws SQLException {
        try(Connection c=DBConnection.getConnection()){
            c.setAutoCommit(false);
            try{
                int seatId=-1;
                try(PreparedStatement p=c.prepareStatement("SELECT seat_id,status FROM bookings WHERE id=? AND user_id=? FOR UPDATE")){
                    p.setInt(1,bookingId);p.setInt(2,userId);
                    try(ResultSet r=p.executeQuery()){
                        if(!r.next() || !"CONFIRMED".equals(r.getString("status"))){c.rollback();return;}
                        seatId=r.getInt("seat_id");
                    }
                }
                try(PreparedStatement p=c.prepareStatement("UPDATE bookings SET status='CANCELLED' WHERE id=?")){
                    p.setInt(1,bookingId);p.executeUpdate();
                }
                try(PreparedStatement p=c.prepareStatement("UPDATE seats SET status='AVAILABLE' WHERE id=?")){
                    p.setInt(1,seatId);p.executeUpdate();
                }
                c.commit();
            }catch(SQLException e){c.rollback();throw e;}finally{c.setAutoCommit(true);}
        }
    }

    public List<Booking> getAllBookings() throws SQLException {
        List<Booking> list=new ArrayList<>();
        String sql="SELECT b.*,e.title,s.seat_number FROM bookings b JOIN events e ON e.id=b.event_id JOIN seats s ON s.id=b.seat_id ORDER BY b.booking_date DESC";
        try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement(sql);ResultSet r=p.executeQuery()){
            while(r.next())list.add(map(r));
        } return list;
    }

    public int countConfirmed() throws SQLException {
        try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement("SELECT COUNT(*) FROM bookings WHERE status='CONFIRMED'");ResultSet r=p.executeQuery()){
            r.next();return r.getInt(1);
        }
    }

    private Booking map(ResultSet r)throws SQLException{
        return new Booking(r.getInt("id"),r.getString("booking_code"),r.getString("title"),
            r.getString("seat_number"),r.getDouble("amount"),r.getString("status"),r.getTimestamp("booking_date"));
    }
}