package com.eventticket.dao;

import com.eventticket.model.User;
import com.eventticket.util.DBConnection;
import com.eventticket.util.PasswordUtil;
import java.sql.*;

public class UserDAO {
    public User login(String email, String password) throws SQLException {
        String sql = "SELECT id,name,email,role,password FROM users WHERE email=?";
        try (Connection c=DBConnection.getConnection(); PreparedStatement p=c.prepareStatement(sql)) {
            p.setString(1, email.trim().toLowerCase());
            try (ResultSet r=p.executeQuery()) {
                if (r.next() && PasswordUtil.verify(password, r.getString("password")))
                    return new User(r.getInt("id"), r.getString("name"), r.getString("email"), r.getString("role"));
            }
        } return null;
    }
    public boolean register(String name, String email, String password) throws SQLException {
        if (name==null || name.trim().length()<2 || email==null || !email.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$") || password==null || password.length()<8)
            throw new IllegalArgumentException("Enter a valid name/email and a password of at least 8 characters.");
        String sql="INSERT INTO users(name,email,password,role) VALUES(?,?,?,'USER')";
        try(Connection c=DBConnection.getConnection(); PreparedStatement p=c.prepareStatement(sql)) {
            p.setString(1,name.trim()); p.setString(2,email.trim().toLowerCase()); p.setString(3,PasswordUtil.hash(password));
            return p.executeUpdate()==1;
        }
    }
}
