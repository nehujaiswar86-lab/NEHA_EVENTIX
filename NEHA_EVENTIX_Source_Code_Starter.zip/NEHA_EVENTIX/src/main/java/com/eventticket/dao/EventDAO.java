package com.eventticket.dao;

import com.eventticket.model.Event;
import com.eventticket.util.DBConnection;
import java.sql.*;
import java.util.*;

public class EventDAO {
    private Event map(ResultSet r) throws SQLException {
        return new Event(r.getInt("id"),r.getString("title"),r.getString("description"),
            r.getDate("event_date"),r.getTime("event_time"),r.getString("venue"),
            r.getDouble("price"),r.getInt("total_seats"),r.getInt("available_seats"));
    }

    public List<Event> getAll(String q) throws SQLException {
        List<Event> list=new ArrayList<>();
        String sql="SELECT e.*, (SELECT COUNT(*) FROM seats s WHERE s.event_id=e.id AND s.status='AVAILABLE') available_seats " +
                   "FROM events e WHERE e.title LIKE ? OR e.venue LIKE ? ORDER BY e.event_date,e.event_time";
        try(Connection c=DBConnection.getConnection(); PreparedStatement p=c.prepareStatement(sql)){
            String x="%"+(q==null?"":q.trim())+"%"; p.setString(1,x); p.setString(2,x);
            try(ResultSet r=p.executeQuery()){while(r.next())list.add(map(r));}
        }
        return list;
    }

    public Event get(int id) throws SQLException {
        String sql="SELECT e.*, (SELECT COUNT(*) FROM seats s WHERE s.event_id=e.id AND s.status='AVAILABLE') available_seats FROM events e WHERE e.id=?";
        try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement(sql)){
            p.setInt(1,id);try(ResultSet r=p.executeQuery()){if(r.next())return map(r);}
        }
        return null;
    }

    public int add(String title,String desc,Date date,Time time,String venue,double price,int total) throws SQLException {
        String sql="INSERT INTO events(title,description,event_date,event_time,venue,price,total_seats) VALUES(?,?,?,?,?,?,?)";
        try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)){
            p.setString(1,title);p.setString(2,desc);p.setDate(3,date);p.setTime(4,time);p.setString(5,venue);p.setDouble(6,price);p.setInt(7,total);
            p.executeUpdate();try(ResultSet k=p.getGeneratedKeys()){if(k.next())return k.getInt(1);}
        } return 0;
    }

    public void delete(int id) throws SQLException {
        try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement("DELETE FROM events WHERE id=?")){
            p.setInt(1,id);p.executeUpdate();
        }
    }
}