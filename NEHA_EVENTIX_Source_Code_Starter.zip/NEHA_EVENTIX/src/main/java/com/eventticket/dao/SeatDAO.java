package com.eventticket.dao;

import com.eventticket.model.Seat;
import com.eventticket.util.DBConnection;
import java.sql.*;
import java.util.*;

public class SeatDAO {
    public List<Seat> getByEvent(int eventId) throws SQLException {
        List<Seat> list=new ArrayList<>();
        String sql="SELECT id,seat_number,status FROM seats WHERE event_id=? ORDER BY id";
        try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement(sql)){
            p.setInt(1,eventId);try(ResultSet r=p.executeQuery()){
                while(r.next()) list.add(new Seat(r.getInt("id"),r.getString("seat_number"),r.getString("status")));
            }
        } return list;
    }

    public void createSeats(Connection c,int eventId,int total) throws SQLException {
        String sql="INSERT INTO seats(event_id,seat_number) VALUES(?,?)";
        try(PreparedStatement p=c.prepareStatement(sql)){
            for(int i=1;i<=total;i++){p.setInt(1,eventId);p.setString(2,"S"+i);p.addBatch();}
            p.executeBatch();
        }
    }
}