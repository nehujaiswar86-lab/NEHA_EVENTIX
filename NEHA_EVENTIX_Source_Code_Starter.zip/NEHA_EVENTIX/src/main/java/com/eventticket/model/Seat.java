package com.eventticket.model;

public class Seat {
    private final int id;
    private final String seatNumber;
    private final String status;

    public Seat(int id, String seatNumber, String status) {
        this.id=id; this.seatNumber=seatNumber; this.status=status;
    }
    public int getId(){return id;} public String getSeatNumber(){return seatNumber;}
    public String getStatus(){return status;}
}