package com.eventticket.model;

import java.sql.Date;
import java.sql.Time;

public class Event {
    private final int id;
    private final String title;
    private final String description;
    private final Date eventDate;
    private final Time eventTime;
    private final String venue;
    private final double price;
    private final int totalSeats;
    private final int availableSeats;

    public Event(int id, String title, String description, Date eventDate, Time eventTime,
                 String venue, double price, int totalSeats, int availableSeats) {
        this.id=id; this.title=title; this.description=description; this.eventDate=eventDate;
        this.eventTime=eventTime; this.venue=venue; this.price=price;
        this.totalSeats=totalSeats; this.availableSeats=availableSeats;
    }
    public int getId(){return id;} public String getTitle(){return title;}
    public String getDescription(){return description;} public Date getEventDate(){return eventDate;}
    public Time getEventTime(){return eventTime;} public String getVenue(){return venue;}
    public double getPrice(){return price;} public int getTotalSeats(){return totalSeats;}
    public int getAvailableSeats(){return availableSeats;}
}