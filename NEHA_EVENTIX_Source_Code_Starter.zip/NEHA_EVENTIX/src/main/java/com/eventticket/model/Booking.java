package com.eventticket.model;

import java.sql.Timestamp;

public class Booking {
    private final int id;
    private final String bookingCode;
    private final String eventTitle;
    private final String seatNumber;
    private final double amount;
    private final String status;
    private final Timestamp bookingDate;

    public Booking(int id, String bookingCode, String eventTitle, String seatNumber,
                   double amount, String status, Timestamp bookingDate) {
        this.id=id; this.bookingCode=bookingCode; this.eventTitle=eventTitle;
        this.seatNumber=seatNumber; this.amount=amount; this.status=status; this.bookingDate=bookingDate;
    }
    public int getId(){return id;} public String getBookingCode(){return bookingCode;}
    public String getEventTitle(){return eventTitle;} public String getSeatNumber(){return seatNumber;}
    public double getAmount(){return amount;} public String getStatus(){return status;}
    public Timestamp getBookingDate(){return bookingDate;}
}