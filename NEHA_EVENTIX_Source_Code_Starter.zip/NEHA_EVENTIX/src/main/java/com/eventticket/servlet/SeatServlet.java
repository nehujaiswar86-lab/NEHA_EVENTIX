package com.eventticket.servlet;
import com.eventticket.dao.*; import javax.servlet.annotation.WebServlet; import javax.servlet.http.*; import java.io.IOException;
@WebServlet("/seats") public class SeatServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws IOException{
        try{int id=Integer.parseInt(req.getParameter("eventId"));req.setAttribute("event",new EventDAO().get(id));req.setAttribute("seats",new SeatDAO().getByEvent(id));req.getRequestDispatcher("/seats.jsp").forward(req,resp);}
        catch(Exception e){throw new RuntimeException(e);}
    }
}