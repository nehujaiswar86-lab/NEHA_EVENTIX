package com.eventticket.servlet;
import com.eventticket.dao.*; import com.eventticket.model.*; import javax.servlet.annotation.WebServlet; import javax.servlet.http.*; import java.io.IOException;
@WebServlet("/book") public class BookingServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req,HttpServletResponse resp)throws IOException{
        User u=(User)req.getSession().getAttribute("user");
        if(u==null){resp.sendRedirect(req.getContextPath()+"/login.jsp");return;}
        try{
            int eventId=Integer.parseInt(req.getParameter("eventId"));
            int seatId=Integer.parseInt(req.getParameter("seatId"));
            Event e=new EventDAO().get(eventId);
            String code=new BookingDAO().book(u.getId(),eventId,seatId,e.getPrice());
            if(code==null)resp.sendRedirect(req.getContextPath()+"/seats?eventId="+eventId+"&error=1");
            else{req.setAttribute("bookingCode",code);req.setAttribute("event",e);req.getRequestDispatcher("/booking-success.jsp").forward(req,resp);}
        }catch(Exception e){throw new RuntimeException(e);}
    }
}