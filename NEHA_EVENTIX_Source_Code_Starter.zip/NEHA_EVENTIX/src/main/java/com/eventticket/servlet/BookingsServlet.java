package com.eventticket.servlet;
import com.eventticket.dao.BookingDAO; import com.eventticket.model.User; import javax.servlet.annotation.WebServlet; import javax.servlet.http.*; import java.io.IOException;
@WebServlet("/my-bookings") public class BookingsServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws IOException{
        User u=(User)req.getSession().getAttribute("user");
        if(u==null){resp.sendRedirect(req.getContextPath()+"/login.jsp");return;}
        try{req.setAttribute("bookings",new BookingDAO().getUserBookings(u.getId()));req.getRequestDispatcher("/my-bookings.jsp").forward(req,resp);}
        catch(Exception e){throw new RuntimeException(e);}
    }
}