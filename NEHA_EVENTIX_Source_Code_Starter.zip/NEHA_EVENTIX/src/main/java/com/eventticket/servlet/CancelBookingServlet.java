package com.eventticket.servlet;
import com.eventticket.dao.BookingDAO; import com.eventticket.model.User; import javax.servlet.annotation.WebServlet; import javax.servlet.http.*; import java.io.IOException;
@WebServlet("/cancel-booking") public class CancelBookingServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req,HttpServletResponse resp)throws IOException{
        User u=(User)req.getSession().getAttribute("user");
        if(u==null){resp.sendRedirect(req.getContextPath()+"/login.jsp");return;}
        try{new BookingDAO().cancel(Integer.parseInt(req.getParameter("bookingId")),u.getId());resp.sendRedirect(req.getContextPath()+"/my-bookings?cancelled=1");}
        catch(Exception e){throw new RuntimeException(e);}
    }
}