package com.eventticket.servlet;
import com.eventticket.dao.EventDAO; import javax.servlet.annotation.WebServlet; import javax.servlet.http.*; import java.io.IOException;
@WebServlet("/events") public class EventServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws IOException{
        try{req.setAttribute("events",new EventDAO().getAll(req.getParameter("q")));req.getRequestDispatcher("/events.jsp").forward(req,resp);}
        catch(Exception e){throw new RuntimeException(e);}
    }
}