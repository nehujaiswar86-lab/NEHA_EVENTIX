package com.eventticket.servlet;
import com.eventticket.dao.UserDAO; import javax.servlet.annotation.WebServlet; import javax.servlet.http.*; import java.io.IOException;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req,HttpServletResponse resp)throws IOException{
        try{
            new UserDAO().register(req.getParameter("name"),req.getParameter("email"),req.getParameter("password"));
            resp.sendRedirect(req.getContextPath()+"/login.jsp?registered=1");
        }catch(Exception e){req.setAttribute("error","Email already exists or registration failed.");req.getRequestDispatcher("/register.jsp").forward(req,resp);}
    }
}