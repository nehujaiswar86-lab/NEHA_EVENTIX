package com.eventticket.servlet;
import com.eventticket.dao.*; import com.eventticket.model.User; import javax.servlet.annotation.WebServlet; import javax.servlet.http.*; import java.io.IOException; import java.sql.*;

@WebServlet("/admin") public class AdminServlet extends HttpServlet {
    private boolean admin(HttpServletRequest r){User u=(User)r.getSession().getAttribute("user");return u!=null&&"ADMIN".equals(u.getRole());}
    protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws IOException{
        if(!admin(req)){resp.sendError(403,"Admin only");return;}
        try{
            req.setAttribute("events",new EventDAO().getAll(null));
            req.setAttribute("bookings",new BookingDAO().getAllBookings());
            req.setAttribute("confirmed",new BookingDAO().countConfirmed());
            req.getRequestDispatcher("/admin.jsp").forward(req,resp);
        }catch(Exception e){throw new RuntimeException(e);}
    }
    protected void doPost(HttpServletRequest req,HttpServletResponse resp)throws IOException{
        if(!admin(req)){resp.sendError(403,"Admin only");return;}
        try{
            String action=req.getParameter("action"); EventDAO ed=new EventDAO();
            if("delete".equals(action)){ed.delete(Integer.parseInt(req.getParameter("id")));}
            else if("add".equals(action)){
                String title=req.getParameter("title"),desc=req.getParameter("description"),venue=req.getParameter("venue");
                Date d=Date.valueOf(req.getParameter("eventDate")); Time t=Time.valueOf(req.getParameter("eventTime")+":00");
                double price=Double.parseDouble(req.getParameter("price")); int total=Integer.parseInt(req.getParameter("totalSeats"));
                int id=ed.add(title,desc,d,t,venue,price,total);
                try(Connection c=com.eventticket.util.DBConnection.getConnection()){new SeatDAO().createSeats(c,id,total);}
            }
            resp.sendRedirect(req.getContextPath()+"/admin");
        }catch(Exception e){throw new RuntimeException(e);}
    }
}