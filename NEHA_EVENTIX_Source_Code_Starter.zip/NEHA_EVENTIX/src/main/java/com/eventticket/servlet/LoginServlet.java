package com.eventticket.servlet;
import com.eventticket.dao.UserDAO; import com.eventticket.model.User;
import javax.servlet.annotation.WebServlet; import javax.servlet.http.*; import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req,HttpServletResponse resp)throws IOException{
        try{
            User u=new UserDAO().login(req.getParameter("email"),req.getParameter("password"));
            if(u!=null){req.getSession().setAttribute("user",u);resp.sendRedirect(req.getContextPath()+"/events");}
            else {req.setAttribute("error","Invalid email or password.");req.getRequestDispatcher("/login.jsp").forward(req,resp);}
        }catch(Exception e){throw new RuntimeException(e);}
    }
}