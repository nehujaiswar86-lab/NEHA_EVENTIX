package com.eventticket.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/** Database settings come from environment variables; never commit real credentials. */
public final class DBConnection {
    private DBConnection() {}
    private static String env(String key, String fallback) {
        String value = System.getenv(key);
        return value == null || value.trim().isEmpty() ? fallback : value;
    }
    static {
        try { Class.forName("com.mysql.cj.jdbc.Driver"); }
        catch (ClassNotFoundException e) { throw new ExceptionInInitializerError(e); }
    }
    public static Connection getConnection() throws SQLException {
        String url = env("DB_URL", "jdbc:mysql://localhost:3306/event_ticketing_db?useSSL=false&serverTimezone=Asia/Kolkata&allowPublicKeyRetrieval=true");
        return DriverManager.getConnection(url, env("DB_USER", "root"), env("DB_PASSWORD", ""));
    }
}
