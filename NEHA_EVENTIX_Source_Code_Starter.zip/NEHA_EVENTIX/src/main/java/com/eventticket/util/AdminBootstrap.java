package com.eventticket.util;

import java.sql.Connection;
import java.sql.PreparedStatement;

/** Run once from a trusted local environment to create an administrator. */
public final class AdminBootstrap {
    public static void main(String[] args) throws Exception {
        if (args.length != 3) { System.err.println("Usage: AdminBootstrap <name> <email> <strong-password>"); System.exit(2); }
        String sql = "INSERT INTO users(name,email,password,role) VALUES(?,?,?,'ADMIN')";
        try (Connection c=DBConnection.getConnection(); PreparedStatement p=c.prepareStatement(sql)) {
            p.setString(1,args[0].trim()); p.setString(2,args[1].trim().toLowerCase()); p.setString(3,PasswordUtil.hash(args[2]));
            p.executeUpdate(); System.out.println("Admin created. Keep the password private and remove it from shell history if needed.");
        }
    }
}
