<!doctype html><html><head><title>Login</title><link rel="stylesheet" href="css/style.css"></head>
<body class="center"><div class="auth card">
<h1>🎟️ EventTicket</h1><h2>Login</h2>
<% if(request.getAttribute("error")!=null){ %><div class="alert error"><%=request.getAttribute("error")%></div><% } %>
<% if(request.getParameter("registered")!=null){ %><div class="alert ok">Registration successful. Login now.</div><% } %>
<form method="post" action="login">
<label>Email</label><input type="email" name="email" required>
<label>Password</label><input type="password" name="password" required>
<button class="primary full">Login</button></form>
<p>New user? <a href="register.jsp">Create account</a></p>
<div class="demo">Admin: admin@gmail.com / admin123<br>User: user@gmail.com / user123</div>
</div></body></html>