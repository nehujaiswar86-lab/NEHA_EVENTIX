<!doctype html><html><head><title>Register</title><link rel="stylesheet" href="css/style.css"></head>
<body class="center"><div class="auth card"><h1>Create Account</h1>
<% if(request.getAttribute("error")!=null){ %><div class="alert error"><%=request.getAttribute("error")%></div><% } %>
<form method="post" action="register">
<label>Name</label><input name="name" required>
<label>Email</label><input type="email" name="email" required>
<label>Password</label><input type="password" name="password" required minlength="4">
<button class="primary full">Register</button></form>
<p><a href="login.jsp">← Back to login</a></p></div></body></html>