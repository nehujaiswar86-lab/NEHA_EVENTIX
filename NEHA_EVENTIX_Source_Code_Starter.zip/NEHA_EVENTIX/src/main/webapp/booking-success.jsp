<!doctype html><html><head><title>Booking Confirmed</title><link rel="stylesheet" href="css/style.css"></head>
<body class="center"><div class="card success-card"><div class="big">✓</div><h1>Booking Confirmed!</h1>
<p>Your ticket has been successfully booked.</p><p>Booking Code</p><div class="ticket-code"><%=request.getAttribute("bookingCode")%></div>
<a class="primary button" href="my-bookings">View My Tickets</a> <a class="button" href="events">More Events</a></div></body></html>