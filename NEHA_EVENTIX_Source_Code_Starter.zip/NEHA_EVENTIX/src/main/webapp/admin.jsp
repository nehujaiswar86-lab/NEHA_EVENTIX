<%@ page import="java.util.List,com.eventticket.model.Event,com.eventticket.model.Booking" %>
<!doctype html><html><head><title>Admin Dashboard</title><link rel="stylesheet" href="css/style.css"></head><body>
<header><div class="brand">🎟️ EventTicket Admin</div><nav><a href="events">User View</a><a href="logout">Logout</a></nav></header>
<main class="container"><h1>Admin Dashboard</h1>
<div class="stats"><div class="stat card"><b><%=((List<Event>)request.getAttribute("events")).size()%></b><span>Events</span></div><div class="stat card"><b><%=request.getAttribute("confirmed")%></b><span>Confirmed Tickets</span></div></div>
<div class="card"><h2>Add New Event</h2><form method="post" action="admin" class="form-grid">
<input type="hidden" name="action" value="add"><input name="title" placeholder="Event title" required><input name="venue" placeholder="Venue" required>
<textarea name="description" placeholder="Description"></textarea><input name="eventDate" type="date" required><input name="eventTime" type="time" required>
<input name="price" type="number" step="0.01" min="0" placeholder="Price" required><input name="totalSeats" type="number" min="1" max="500" placeholder="Seats" required>
<button class="primary">Add Event</button></form></div>
<div class="card"><h2>Events</h2><div class="table-wrap"><table><tr><th>ID</th><th>Title</th><th>Date</th><th>Venue</th><th>Price</th><th>Seats</th><th>Action</th></tr>
<% for(Event e:(List<Event>)request.getAttribute("events")){%><tr><td><%=e.getId()%></td><td><%=e.getTitle()%></td><td><%=e.getEventDate()%></td><td><%=e.getVenue()%></td><td>₹<%=e.getPrice()%></td><td><%=e.getAvailableSeats()%>/<%=e.getTotalSeats()%></td><td>
<form method="post" action="admin" onsubmit="return confirm('Delete this event?')"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<%=e.getId()%>"><button class="danger">Delete</button></form></td></tr><%}%></table></div></div>
<div class="card"><h2>Recent Bookings</h2><div class="table-wrap"><table><tr><th>Code</th><th>Event</th><th>Seat</th><th>Amount</th><th>Status</th></tr>
<% for(Booking b:(List<Booking>)request.getAttribute("bookings")){%><tr><td><%=b.getBookingCode()%></td><td><%=b.getEventTitle()%></td><td><%=b.getSeatNumber()%></td><td>₹<%=b.getAmount()%></td><td><%=b.getStatus()%></td></tr><%}%></table></div></div>
</main></body></html>