<%@ page import="java.util.List,com.eventticket.model.Booking,com.eventticket.model.User" %>
<!doctype html><html><head><title>My Tickets</title><link rel="stylesheet" href="css/style.css"></head><body>
<header><div class="brand">🎟️ EventTicket</div><nav><a href="events">Events</a><a href="logout">Logout</a></nav></header>
<main class="container"><h1>My Tickets</h1>
<% if(request.getParameter("cancelled")!=null){%><div class="alert ok">Ticket cancelled and seat released.</div><%}%>
<div class="table-wrap"><table><tr><th>Code</th><th>Event</th><th>Seat</th><th>Amount</th><th>Status</th><th>Date</th><th>Action</th></tr>
<% for(Booking b:(List<Booking>)request.getAttribute("bookings")){ %>
<tr><td><b><%=b.getBookingCode()%></b></td><td><%=b.getEventTitle()%></td><td><%=b.getSeatNumber()%></td><td>₹<%=b.getAmount()%></td>
<td><span class="status <%=b.getStatus().toLowerCase()%>"><%=b.getStatus()%></span></td><td><%=b.getBookingDate()%></td><td>
<% if("CONFIRMED".equals(b.getStatus())){%><form method="post" action="cancel-booking" onsubmit="return confirm('Cancel this ticket?')"><input type="hidden" name="bookingId" value="<%=b.getId()%>"><button class="danger">Cancel</button></form><% } else {%>-<%}%>
</td></tr><% } %></table></div></main></body></html>