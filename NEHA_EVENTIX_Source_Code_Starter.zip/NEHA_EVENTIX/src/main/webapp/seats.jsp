<%@ page import="java.util.List,com.eventticket.model.Seat,com.eventticket.model.Event,com.eventticket.model.User" %>
<!doctype html><html><head><title>Seats</title><link rel="stylesheet" href="css/style.css"></head><body>
<header><div class="brand">🎟️ EventTicket</div><nav><a href="events">Events</a><% if(session.getAttribute("user")!=null){%><a href="my-bookings">My Tickets</a><a href="logout">Logout</a><%}%></nav></header>
<main class="container"><% Event e=(Event)request.getAttribute("event"); %>
<div class="card"><h1><%=e.getTitle()%></h1><p>📍 <%=e.getVenue()%> &nbsp; 📅 <%=e.getEventDate()%> &nbsp; ₹<%=e.getPrice()%></p>
<% if(request.getParameter("error")!=null){%><div class="alert error">This seat was just booked. Please select another.</div><%}%>
<div class="screen">STAGE / SCREEN</div><div class="seat-grid">
<% for(Seat s:(List<Seat>)request.getAttribute("seats")){ boolean booked="BOOKED".equals(s.getStatus()); %>
<form method="post" action="book"><input type="hidden" name="eventId" value="<%=e.getId()%>"><input type="hidden" name="seatId" value="<%=s.getId()%>">
<button class="seat <%=booked?"booked":""%>" <%=booked?"disabled":""%> title="<%=booked?"Booked":"Available"%>"><%=s.getSeatNumber()%></button></form>
<% } %></div><div class="legend"><span>🟩 Available</span><span>⬜ Booked</span></div>
</div></main></body></html>