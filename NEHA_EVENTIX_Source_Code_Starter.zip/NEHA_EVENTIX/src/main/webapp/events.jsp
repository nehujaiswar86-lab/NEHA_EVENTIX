<%@ page import="java.util.List,com.eventticket.model.Event,com.eventticket.model.User" %>
<!doctype html><html><head><title>Events</title><link rel="stylesheet" href="css/style.css"></head><body>
<header><div class="brand">🎟️ EventTicket</div><nav><a href="events">Events</a>
<% User u=(User)session.getAttribute("user"); if(u!=null){ %>
<a href="my-bookings">My Tickets</a><% if("ADMIN".equals(u.getRole())){%><a href="admin">Admin</a><%}%><a href="logout">Logout</a>
<% }else{ %><a href="login.jsp">Login</a><% } %></nav></header>
<main class="container"><div class="hero"><div><h1>Find Your Next Event</h1><p>Choose an event, select your seat and book your ticket.</p></div></div>
<form class="search" method="get" action="events"><input name="q" value="<%=request.getParameter("q")==null?"":request.getParameter("q")%>" placeholder="Search event or venue..."><button class="primary">Search</button></form>
<div class="grid">
<% for(Event e:(List<Event>)request.getAttribute("events")){ %>
<article class="card event"><span class="tag"><%=e.getAvailableSeats()%> seats left</span><h2><%=e.getTitle()%></h2><p><%=e.getDescription()%></p>
<div class="meta">📅 <%=e.getEventDate()%> &nbsp; ⏰ <%=e.getEventTime()%></div><div class="meta">📍 <%=e.getVenue()%></div>
<div class="price">₹<%=String.format("%.2f",e.getPrice())%></div>
<a class="primary button" href="seats?eventId=<%=e.getId()%>">Select Seat</a></article>
<% } %></div></main></body></html>