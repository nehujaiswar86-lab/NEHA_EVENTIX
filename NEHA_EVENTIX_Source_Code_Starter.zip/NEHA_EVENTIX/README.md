# NEHA EVENTIX — Events • Tickets • Experiences

Academic project: **Event Ticketing & Intelligent Seat Allocation System**
Student: Neha Subhash Jaiswar | SY BSc IT | Roll No. 18013 | Academic Year 2026–27

## Stack
Java 11, JSP, Servlets (`javax.servlet` / Tomcat 9), JDBC, MySQL 8, Maven, HTML/CSS/JavaScript.

## Current starter features
- User registration/login/logout (passwords now use PBKDF2-HMAC-SHA256 salted hashes).
- Event listing, seat selection, booking, booking history and cancellation from the original starter.
- Admin dashboard and event management in the original starter; admin role must be created securely using the bootstrap utility below.
- JDBC credentials are read from environment variables instead of being committed in Java source.
- NEHA EVENTIX visual theme.

**Important:** This is a strengthened starter, not a security-audited production ticketing platform. Before taking real payments or public traffic, review authorization on every endpoint, CSRF protections, input/output encoding, rate limiting, notifications, cancellation rules, event deletion constraints and automated tests. No real payment gateway or email service is configured.

## 1. Requirements
Install JDK 11, Maven, MySQL 8, and Apache Tomcat 9.

## 2. Create database
Run `database.sql` in MySQL. It creates `event_ticketing_db` and sample event/seat data. **It no longer inserts public demo passwords.**

## 3. Set database environment variables (Windows PowerShell)
```powershell
$env:DB_URL="jdbc:mysql://localhost:3306/event_ticketing_db?useSSL=false&serverTimezone=Asia/Kolkata&allowPublicKeyRetrieval=true"
$env:DB_USER="root"
$env:DB_PASSWORD="YOUR_LOCAL_MYSQL_PASSWORD"
```
Use your own local MySQL password. Never commit secrets to GitHub.

## 4. Create an admin account
The utility `com.eventticket.util.AdminBootstrap` creates an ADMIN user with a hashed password. Build the project first, then run it from a trusted local environment with the project's compiled classes and MySQL JDBC dependency on the classpath. Example argument shape: `AdminBootstrap "Site Admin" "admin@example.com" "a-unique-strong-password"`. Do not publish the password. Do not create an admin account through public registration.

## 5. Build WAR
From this folder run:
```powershell
mvn clean package
```
WAR output: `target/EventTicketingSystem.war`. Copy it to Tomcat's `webapps` folder and start Tomcat. Open `http://localhost:8080/EventTicketingSystem/`.

## 6. GitHub
Create a **private** repository initially. Upload the project folder contents (not the ZIP alone). Check that no database password, API key, or private admin credentials are committed. Suggested `.gitignore` entries: `target/`, `.idea/`, `.vscode/`, `.env`, `*.log`.

## 7. Online deployment
This is a Tomcat WAR application, so GitHub Pages and static-only Netlify/Vercel hosting cannot run its Java backend directly. Choose a Java/Tomcat-compatible host (or Docker host) plus a managed MySQL database. Set `DB_URL`, `DB_USER`, and `DB_PASSWORD` in the hosting dashboard, deploy the WAR/container, then test registration, login, seat booking, cancellation and admin access. Use HTTPS. Actual deployment requires your hosting account and database credentials; never send passwords in chat.

## Known limitation
This source bundle is based on a small academic starter. Maven was not available in the build environment at the time this ZIP was prepared, so a successful compile/deploy has **not** been verified here. Run `mvn clean package` locally and share any exact error output for fixes.
