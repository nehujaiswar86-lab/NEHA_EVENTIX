CREATE DATABASE IF NOT EXISTS event_ticketing_db
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE event_ticketing_db;

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS seats;
DROP TABLE IF EXISTS events;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('USER','ADMIN') NOT NULL DEFAULT 'USER',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE events (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    event_date DATE NOT NULL,
    event_time TIME NOT NULL,
    venue VARCHAR(200) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    total_seats INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE seats (
    id INT PRIMARY KEY AUTO_INCREMENT,
    event_id INT NOT NULL,
    seat_number VARCHAR(10) NOT NULL,
    status ENUM('AVAILABLE','BOOKED') NOT NULL DEFAULT 'AVAILABLE',
    UNIQUE KEY uk_event_seat(event_id, seat_number),
    CONSTRAINT fk_seat_event FOREIGN KEY(event_id) REFERENCES events(id) ON DELETE CASCADE
);

CREATE TABLE bookings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    event_id INT NOT NULL,
    seat_id INT NOT NULL,
    booking_code VARCHAR(30) NOT NULL UNIQUE,
    amount DECIMAL(10,2) NOT NULL,
    status ENUM('CONFIRMED','CANCELLED') NOT NULL DEFAULT 'CONFIRMED',
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_booking_user FOREIGN KEY(user_id) REFERENCES users(id),
    CONSTRAINT fk_booking_event FOREIGN KEY(event_id) REFERENCES events(id),
    CONSTRAINT fk_booking_seat FOREIGN KEY(seat_id) REFERENCES seats(id)
);

-- Create the first ADMIN account using the AdminBootstrap utility (see README).

INSERT INTO events(title,description,event_date,event_time,venue,price,total_seats) VALUES
('Music Night','Live music, dance and entertainment.','2026-11-20','18:30:00','Mumbai City Auditorium',499.00,40),
('Comedy Show','A fun stand-up comedy evening.','2026-11-25','19:00:00','Andheri Convention Hall',299.00,30),
('College Fest','Annual college cultural festival.','2026-12-05','10:00:00','College Ground',199.00,50);

DELIMITER $$

CREATE PROCEDURE seed_seats(IN p_event_id INT, IN p_total INT)
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i <= p_total DO
        INSERT INTO seats(event_id, seat_number) VALUES(p_event_id, CONCAT('S', i));
        SET i = i + 1;
    END WHILE;
END$$

DELIMITER ;

CALL seed_seats(1,40);
CALL seed_seats(2,30);
CALL seed_seats(3,50);

DROP PROCEDURE seed_seats;